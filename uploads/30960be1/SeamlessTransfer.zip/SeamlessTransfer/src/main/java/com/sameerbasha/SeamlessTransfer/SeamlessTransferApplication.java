package com.sameerbasha.SeamlessTransfer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeamlessTransferApplication {

	public static void main(String[] args) {
		SpringApplication.run(SeamlessTransferApplication.class, args);
	}

}
