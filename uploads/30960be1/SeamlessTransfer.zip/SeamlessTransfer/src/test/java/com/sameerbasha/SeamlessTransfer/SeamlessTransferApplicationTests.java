package com.sameerbasha.SeamlessTransfer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeamlessTransferApplicationTests {

	@Test
	void contextLoads() {
	}

}
